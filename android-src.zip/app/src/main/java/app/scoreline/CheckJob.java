package app.scoreline;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Context;

/** Android runs this about every 15 minutes: finds upcoming games, checks news, and starts live tracking when a game is on. */
public class CheckJob extends JobService {
    @Override
    public boolean onStartJob(final JobParameters params) {
        final Context c = getApplicationContext();
        new Thread(() -> {
            try {
                Alerts.run(c, false);
                if (Alerts.needsLive(c)) Alerts.startLive(c);
            } catch (Exception ignored) {
            }
            jobFinished(params, false);
        }).start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) { return true; }
}
