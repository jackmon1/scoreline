package app.scoreline;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Runs only while one of your teams is playing: checks the score every minute and shows it in the notification shade. */
public class LiveService extends Service {
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private boolean running = false;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            Alerts.channels(this);
            Notification n = Alerts.liveNotification(this, new ArrayList<String>());
            if (Build.VERSION.SDK_INT >= 34) startForeground(Alerts.LIVE_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else startForeground(Alerts.LIVE_ID, n);
        } catch (Throwable e) {
            Alerts.prefs(this).edit().putString("lastError", "Live tracking couldn't start: " + e).apply();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!running) {
            running = true;
            tick();
        }
        return START_STICKY;
    }

    private void tick() {
        worker.execute(() -> {
            List<String> lines;
            try {
                lines = Alerts.run(getApplicationContext(), true);
            } catch (Exception e) {
                lines = new ArrayList<>();
                lines.add("Reconnecting…");
            }
            final List<String> result = lines;
            main.post(() -> {
                if (!running) return;
                if (result.isEmpty()) {
                    running = false;
                    stopForeground(STOP_FOREGROUND_REMOVE);
                    stopSelf();
                    return;
                }
                try {
                    NotificationManager nm = getSystemService(NotificationManager.class);
                    nm.notify(Alerts.LIVE_ID, Alerts.liveNotification(this, result));
                } catch (Throwable ignored) { }
                main.postDelayed(this::tick, 60_000L);
            });
        });
    }

    @Override
    public void onDestroy() {
        running = false;
        main.removeCallbacksAndMessages(null);
        worker.shutdownNow();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
