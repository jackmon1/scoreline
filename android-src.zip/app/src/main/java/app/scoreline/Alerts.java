package app.scoreline;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** The alert engine: finds your teams' games, follows them live, and posts notifications. */
public final class Alerts {
    static final String CH_GAME = "game", CH_LIVE = "live", CH_NEWS = "news";
    static final int LIVE_ID = 1, JOB_ID = 7;
    static final String ACTION_LIVE = "app.scoreline.LIVE";
    static final String SITE = "https://site.api.espn.com/apis/site/v2/sports/";
    static final String CORE = "https://sports.core.api.espn.com/v2/sports/";
    static final long MIN = 60_000L, HOUR = 60 * MIN;
    private static final Object LOCK = new Object();

    private Alerts() {}

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("alerts", Context.MODE_PRIVATE); }

    static void channels(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        NotificationChannel g = new NotificationChannel(CH_GAME, "Game alerts", NotificationManager.IMPORTANCE_HIGH);
        g.setDescription("Game starts, scoring updates and final scores for your teams");
        NotificationChannel n = new NotificationChannel(CH_NEWS, "Team news", NotificationManager.IMPORTANCE_DEFAULT);
        n.setDescription("New stories about your teams");
        NotificationChannel l = new NotificationChannel(CH_LIVE, "Live game tracker", NotificationManager.IMPORTANCE_LOW);
        l.setDescription("Shows the live score while Scoreline follows your team's game");
        l.setShowBadge(false);
        nm.createNotificationChannel(g);
        nm.createNotificationChannel(n);
        nm.createNotificationChannel(l);
    }

    /* ---------- settings from the app ---------- */
    static JSONObject config(Context c) {
        try { return new JSONObject(prefs(c).getString("config", "{}")); } catch (JSONException e) { return new JSONObject(); }
    }
    static void setConfig(Context c, String json) {
        prefs(c).edit().putString("config", json).putLong("disc", 0).apply();
        schedule(c);
    }
    static boolean wants(JSONObject cfg, String key, String cat) {
        if (!cfg.optBoolean("on", true)) return false;
        JSONArray teams = cfg.optJSONArray("teams");
        if (teams == null) return false;
        for (int i = 0; i < teams.length(); i++) {
            JSONObject t = teams.optJSONObject(i);
            if (t == null) continue;
            if ((t.optString("lg") + ":" + t.optString("id")).equals(key)) {
                JSONObject cats = t.optJSONObject("cats");
                if (cats != null && cats.optBoolean(cat, false)) return true;
            }
        }
        return false;
    }
    static boolean anyCat(JSONObject t, String... cats) {
        JSONObject c = t.optJSONObject("cats");
        if (c == null) return false;
        for (String x : cats) if (c.optBoolean(x, false)) return true;
        return false;
    }

    /* ---------- network ---------- */
    static String get(String url) throws IOException {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(15000);
        con.setReadTimeout(20000);
        con.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) ScorelineApp");
        con.setRequestProperty("Accept", "application/json, application/rss+xml, text/xml, */*");
        try {
            int code = con.getResponseCode();
            if (code < 200 || code >= 300) throw new IOException("HTTP " + code);
            try (InputStream in = con.getInputStream()) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                return new String(out.toByteArray(), StandardCharsets.UTF_8);
            }
        } finally {
            con.disconnect();
        }
    }
    static JSONObject getJson(String url) throws IOException {
        try { return new JSONObject(get(url)); } catch (JSONException e) { throw new IOException("Bad data from " + url); }
    }
    static long parseTime(String s) {
        try { return OffsetDateTime.parse(s).toInstant().toEpochMilli(); } catch (Exception e) { return 0; }
    }
    static String scoreOf(JSONObject competitor) {
        Object s = competitor.opt("score");
        if (s instanceof JSONObject) {
            JSONObject o = (JSONObject) s;
            return o.has("displayValue") ? o.optString("displayValue") : o.optString("value", "");
        }
        return s == null ? "" : String.valueOf(s);
    }

    /* ---------- stored game state ---------- */
    static JSONObject loadGames(Context c) {
        try { return new JSONObject(prefs(c).getString("games", "{}")); } catch (JSONException e) { return new JSONObject(); }
    }
    static void saveGames(Context c, JSONObject g) { prefs(c).edit().putString("games", g.toString()).apply(); }

    /** Looks up today's and tomorrow's games for every team with game alerts on. */
    static void discover(Context c, JSONObject cfg, long now, List<String> errors) throws JSONException {
        JSONObject games = loadGames(c);
        JSONArray teams = cfg.optJSONArray("teams");
        if (teams != null) for (int i = 0; i < teams.length(); i++) {
            JSONObject t = teams.optJSONObject(i);
            if (t == null || !anyCat(t, "start", "score", "final")) continue;
            String lg = t.optString("lg"), path = t.optString("path"), id = t.optString("id");
            try {
                JSONObject d = getJson(SITE + path + "/teams/" + id + "/schedule");
                JSONArray evs = d.optJSONArray("events");
                if (evs == null) continue;
                for (int k = 0; k < evs.length(); k++) {
                    JSONObject ev = evs.optJSONObject(k);
                    if (ev == null) continue;
                    long start = parseTime(ev.optString("date"));
                    JSONArray comps = ev.optJSONArray("competitions");
                    JSONObject comp = comps == null ? null : comps.optJSONObject(0);
                    if (comp == null || start <= now - 10 * HOUR || start >= now + 36 * HOUR) continue;
                    JSONObject type = comp.optJSONObject("status") == null ? null : comp.optJSONObject("status").optJSONObject("type");
                    String st = type == null ? "pre" : type.optString("state", "pre");
                    if ("post".equals(st)) continue;
                    JSONArray cs = comp.optJSONArray("competitors");
                    if (cs == null || cs.length() < 2) continue;
                    JSONObject away = null, home = null;
                    for (int j = 0; j < cs.length(); j++) {
                        JSONObject x = cs.optJSONObject(j);
                        if (x == null) continue;
                        if ("home".equals(x.optString("homeAway"))) home = x; else away = x;
                    }
                    if (away == null || home == null) continue;
                    String evId = ev.optString("id");
                    JSONObject g = games.optJSONObject(evId);
                    if (g == null) {
                        g = new JSONObject();
                        g.put("state", st);
                        g.put("a", "pre".equals(st) ? "" : scoreOf(away));
                        g.put("h", "pre".equals(st) ? "" : scoreOf(home));
                        g.put("period", 0);
                        g.put("updated", now);
                    }
                    JSONObject at = away.optJSONObject("team"), ht = home.optJSONObject("team");
                    if (at == null) at = new JSONObject();
                    if (ht == null) ht = new JSONObject();
                    g.put("lg", lg).put("path", path).put("start", start);
                    g.put("aid", away.has("id") ? away.optString("id") : at.optString("id"));
                    g.put("hid", home.has("id") ? home.optString("id") : ht.optString("id"));
                    g.put("aab", at.optString("abbreviation", at.optString("shortDisplayName")));
                    g.put("hab", ht.optString("abbreviation", ht.optString("shortDisplayName")));
                    g.put("an", at.optString("shortDisplayName", at.optString("displayName")));
                    g.put("hn", ht.optString("shortDisplayName", ht.optString("displayName")));
                    JSONArray bc = comp.optJSONArray("broadcasts");
                    JSONObject b0 = bc == null ? null : bc.optJSONObject(0);
                    g.put("tv", b0 != null && b0.optJSONObject("media") != null ? b0.optJSONObject("media").optString("shortName") : "");
                    games.put(evId, g);
                }
            } catch (IOException e) {
                errors.add(t.optString("short", t.optString("name")) + " schedule: " + e.getMessage());
            }
        }
        // drop old games
        Iterator<String> it = games.keys();
        List<String> drop = new ArrayList<>();
        while (it.hasNext()) {
            String k = it.next();
            JSONObject g = games.optJSONObject(k);
            if (g == null || g.optLong("start") < now - 48 * HOUR || ("post".equals(g.optString("state")) && g.optLong("updated") < now - 6 * HOUR)) drop.add(k);
        }
        for (String k : drop) games.remove(k);
        saveGames(c, games);
    }

    static String startWord(String sport) {
        switch (sport) {
            case "football": case "soccer": return "Kickoff";
            case "basketball": return "Tip-off";
            case "baseball": return "First pitch";
            case "hockey": return "Puck drop";
            case "volleyball": return "First serve";
            case "lacrosse": return "Faceoff";
            default: return "Underway";
        }
    }
    static String ord(int n) {
        int m = n % 100;
        if (m >= 11 && m <= 13) return n + "th";
        switch (n % 10) { case 1: return n + "st"; case 2: return n + "nd"; case 3: return n + "rd"; default: return n + "th"; }
    }

    /** Checks every game that is on now. Returns one line per game being followed. */
    static List<String> checkGames(Context c, JSONObject cfg, long now, List<String> errors) throws JSONException {
        JSONObject games = loadGames(c);
        List<String> lines = new ArrayList<>();
        Iterator<String> it = games.keys();
        List<String> ids = new ArrayList<>();
        while (it.hasNext()) ids.add(it.next());
        boolean changedAny = false;
        for (String id : ids) {
            JSONObject g = games.optJSONObject(id);
            if (g == null) continue;
            long start = g.optLong("start");
            String prev = g.optString("state", "pre");
            if ("post".equals(prev)) continue;
            if (start > now + 15 * MIN || start < now - 10 * HOUR) continue;
            String lg = g.optString("lg"), path = g.optString("path");
            String[] p = path.split("/");
            if (p.length < 2) continue;
            String sport = p[0];
            if (start > now + 3 * MIN) { // starting soon: keep the tracker up, no network yet
                lines.add(g.optString("an") + " at " + g.optString("hn") + " starts soon");
                continue;
            }
            String base = CORE + sport + "/leagues/" + p[1] + "/events/" + id + "/competitions/" + id;
            JSONObject st;
            try { st = getJson(base + "/status"); } catch (IOException e) { errors.add("status: " + e.getMessage()); lines.add(g.optString("an") + " at " + g.optString("hn")); continue; }
            JSONObject type = st.optJSONObject("type");
            if (type == null) type = new JSONObject();
            String state = type.optString("state", prev);
            String a = g.optString("a"), h = g.optString("h");
            if (!"pre".equals(state)) {
                try {
                    JSONObject as = getJson(base + "/competitors/" + g.optString("aid") + "/score");
                    JSONObject hs = getJson(base + "/competitors/" + g.optString("hid") + "/score");
                    a = as.has("displayValue") ? as.optString("displayValue") : as.optString("value", a);
                    h = hs.has("displayValue") ? hs.optString("displayValue") : hs.optString("value", h);
                } catch (IOException e) { errors.add("score: " + e.getMessage()); }
            }
            int period = st.optInt("period", 0);
            String detail = type.optString("shortDetail", type.optString("detail", ""));
            String line = g.optString("aab") + " " + a + " – " + g.optString("hab") + " " + h;
            if ("in".equals(state)) lines.add(line + (detail.isEmpty() ? "" : " · " + detail));
            else if ("pre".equals(state)) lines.add(g.optString("an") + " at " + g.optString("hn") + " starts soon");

            boolean changed = !state.equals(prev) || !a.equals(g.optString("a")) || !h.equals(g.optString("h")) || period != g.optInt("period");
            if (!changed) continue;
            String ka = lg + ":" + g.optString("aid"), kh = lg + ":" + g.optString("hid");
            String hash = "#g-" + lg + "-" + id;
            String cat = null, title = null, body = null;
            if ("pre".equals(prev) && "in".equals(state)) {
                cat = "start"; title = startWord(sport) + ": " + g.optString("an") + " at " + g.optString("hn");
                body = g.optString("tv").isEmpty() ? "The game is underway" : "On " + g.optString("tv");
            } else if (!"post".equals(prev) && "post".equals(state)) {
                cat = "final"; title = "Final: " + line; body = type.optString("detail", "Final");
            } else if ("in".equals(state) && "in".equals(prev)) {
                boolean periodic = "basketball".equals(sport) || "volleyball".equals(sport);
                int prevPeriod = g.optInt("period");
                if (periodic ? (prevPeriod > 0 && period > prevPeriod) : (!a.equals(g.optString("a")) || !h.equals(g.optString("h")))) {
                    cat = "score"; title = line; body = (periodic ? "End of " + ord(prevPeriod) + " · " : "") + detail;
                }
            }
            if (cat != null && (wants(cfg, ka, cat) || wants(cfg, kh, cat))) post(c, CH_GAME, "g" + id, title, body, hash);
            g.put("state", state).put("a", a).put("h", h).put("period", period).put("updated", now);
            changedAny = true;
        }
        if (changedAny) saveGames(c, games);
        return lines;
    }

    static boolean tagged(JSONObject art, String teamId) {
        JSONArray cats = art.optJSONArray("categories");
        if (cats == null) return false;
        for (int i = 0; i < cats.length(); i++) {
            JSONObject x = cats.optJSONObject(i);
            if (x == null) continue;
            String tid = x.has("teamId") ? x.optString("teamId") : (x.optJSONObject("team") != null ? x.optJSONObject("team").optString("id") : "");
            if (teamId.equals(tid)) return true;
        }
        return false;
    }

    /** Posts alerts for new stories tagged to your teams (at most every 15 minutes). */
    static void news(Context c, JSONObject cfg, long now, List<String> errors) {
        SharedPreferences sp = prefs(c);
        if (now - sp.getLong("news", 0) < 14 * MIN) return;
        sp.edit().putLong("news", now).apply();
        JSONArray teams = cfg.optJSONArray("teams");
        if (teams == null || !cfg.optBoolean("on", true)) return;
        for (int i = 0; i < teams.length(); i++) {
            JSONObject t = teams.optJSONObject(i);
            if (t == null || !anyCat(t, "news")) continue;
            String lg = t.optString("lg"), id = t.optString("id"), key = "seen:" + lg + ":" + id;
            try {
                JSONObject d = getJson(SITE + t.optString("path") + "/news?team=" + id + "&limit=40");
                JSONArray arts = d.optJSONArray("articles");
                if (arts == null) continue;
                Set<String> seen = new HashSet<>(sp.getStringSet(key, new HashSet<String>()));
                boolean first = !sp.contains(key);
                Set<String> now_ids = new LinkedHashSet<>();
                int sent = 0;
                for (int k = 0; k < arts.length(); k++) {
                    JSONObject a = arts.optJSONObject(k);
                    if (a == null || a.optString("headline").isEmpty() || !tagged(a, id)) continue;
                    String aid = a.optString("id", a.optString("headline"));
                    now_ids.add(aid);
                    if (!first && !seen.contains(aid) && sent < 2) {
                        post(c, CH_NEWS, "n" + aid, t.optString("short", t.optString("name")) + " news", a.optString("headline"), "#t-" + lg + "-" + id);
                        sent++;
                    }
                }
                seen.addAll(now_ids);
                if (seen.size() > 120) { Set<String> keep = new HashSet<>(now_ids); seen = keep; }
                sp.edit().putStringSet(key, seen).apply();
            } catch (IOException e) {
                errors.add(t.optString("short") + " news: " + e.getMessage());
            }
        }
    }

    /* ---------- the regular check (every ~15 minutes, and every minute during games) ---------- */
    static List<String> run(Context c, boolean live) {
        synchronized (LOCK) {
            long now = System.currentTimeMillis();
            List<String> errors = new ArrayList<>();
            List<String> lines = new ArrayList<>();
            JSONObject cfg = config(c);
            SharedPreferences sp = prefs(c);
            try {
                JSONArray teams = cfg.optJSONArray("teams");
                if (teams != null && teams.length() > 0 && cfg.optBoolean("on", true)) {
                    if (now - sp.getLong("disc", 0) > (live ? 60 : 25) * MIN) {
                        discover(c, cfg, now, errors);
                        sp.edit().putLong("disc", now).apply();
                    }
                    lines = checkGames(c, cfg, now, errors);
                    news(c, cfg, now, errors);
                }
            } catch (Exception e) {
                errors.add(String.valueOf(e.getMessage()));
            }
            sp.edit().putLong("lastRun", now).putString("lastError", errors.isEmpty() ? "" : errors.get(0)).putInt("liveNow", lines.size()).apply();
            scheduleAlarm(c, now);
            return lines;
        }
    }

    /* ---------- scheduling ---------- */
    static void schedule(Context c) {
        JobScheduler js = c.getSystemService(JobScheduler.class);
        if (js != null && js.getPendingJob(JOB_ID) == null) {
            JobInfo job = new JobInfo.Builder(JOB_ID, new ComponentName(c, CheckJob.class))
                    .setPeriodic(15 * MIN)
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPersisted(true)
                    .build();
            js.schedule(job);
        }
        scheduleAlarm(c, System.currentTimeMillis());
    }

    /** Wakes the app a few minutes before the next game so it can start following it. */
    static void scheduleAlarm(Context c, long now) {
        JSONObject games = loadGames(c);
        long next = Long.MAX_VALUE;
        Iterator<String> it = games.keys();
        while (it.hasNext()) {
            JSONObject g = games.optJSONObject(it.next());
            if (g == null || "post".equals(g.optString("state"))) continue;
            long s = g.optLong("start") - 5 * MIN;
            if (s > now && s < next) next = s;
        }
        AlarmManager am = c.getSystemService(AlarmManager.class);
        Intent i = new Intent(c, AlarmReceiver.class).setAction(ACTION_LIVE);
        PendingIntent pi = PendingIntent.getBroadcast(c, 3, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (am == null) return;
        am.cancel(pi);
        if (next != Long.MAX_VALUE) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi);
    }

    static boolean needsLive(Context c) {
        long now = System.currentTimeMillis();
        JSONObject games = loadGames(c);
        Iterator<String> it = games.keys();
        while (it.hasNext()) {
            JSONObject g = games.optJSONObject(it.next());
            if (g == null || "post".equals(g.optString("state"))) continue;
            long s = g.optLong("start");
            if (s <= now + 15 * MIN && s > now - 10 * HOUR) return true;
        }
        return false;
    }

    /** Starts the live tracker. Android only allows this from the background when battery use is unrestricted. */
    static boolean startLive(Context c) {
        try {
            c.startForegroundService(new Intent(c, LiveService.class));
            return true;
        } catch (Exception e) {
            prefs(c).edit().putString("lastError", "Android blocked live tracking. Set Scoreline's battery use to Unrestricted.").apply();
            return false;
        }
    }

    /* ---------- notifications ---------- */
    static PendingIntent open(Context c, String hash, int req) {
        Intent i = new Intent(c, MainActivity.class).putExtra("hash", hash).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(c, req, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    static void post(Context c, String channel, String tag, String title, String body, String hash) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        int id = (tag + channel).hashCode() & 0x7fffffff;
        if (id <= LIVE_ID) id += 2;
        Notification n = new Notification.Builder(c, channel)
                .setSmallIcon(R.drawable.ic_stat)
                .setColor(0xff1d4ed8)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setShowWhen(true)
                .setContentIntent(open(c, hash, id))
                .build();
        nm.notify(id, n);
    }
    static Notification liveNotification(Context c, List<String> lines) {
        String title = lines.isEmpty() ? "Following your teams" : (lines.size() == 1 ? lines.get(0) : "Following " + lines.size() + " games");
        String text = lines.isEmpty() ? "Checking scores…" : (lines.size() == 1 ? "Live alerts are on" : lines.get(0));
        Notification.InboxStyle style = new Notification.InboxStyle();
        for (String l : lines) style.addLine(l);
        Notification.Builder b = new Notification.Builder(c, CH_LIVE)
                .setSmallIcon(R.drawable.ic_stat)
                .setColor(0xff1d4ed8)
                .setContentTitle(title)
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setContentIntent(open(c, "#scores", LIVE_ID));
        if (lines.size() > 1) b.setStyle(style);
        return b.build();
    }
}
