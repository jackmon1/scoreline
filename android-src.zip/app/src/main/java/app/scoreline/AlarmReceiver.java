package app.scoreline;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Restarts the regular checks after a reboot or app update, and starts live tracking just before a game. */
public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Context c = context.getApplicationContext();
        String action = intent == null ? null : intent.getAction();
        if (Alerts.ACTION_LIVE.equals(action)) {
            Alerts.startLive(c);
        } else {
            Alerts.schedule(c);
        }
    }
}
