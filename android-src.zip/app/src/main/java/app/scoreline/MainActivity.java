package app.scoreline;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Shows the Scoreline app and connects it to Android's notifications. */
public class MainActivity extends Activity {
    private WebView web;
    private final ExecutorService io = Executors.newFixedThreadPool(4);
    private static final int REQ_NOTIF = 7;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        Alerts.channels(this);
        Alerts.schedule(this);
        paintBars();

        web = new WebView(this);
        web.setBackgroundColor(night() ? 0xff0a0e14 : 0xfff2f4f7);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setUserAgentString(s.getUserAgentString() + " ScorelineApp/" + BuildConfig.VERSION_NAME);
        web.addJavascriptInterface(new Bridge(), "ScorelineNative");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (isApp(u)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame()) showOffline();
            }
        });

        if (saved != null) web.restoreState(saved);
        else web.loadUrl(BuildConfig.APP_URL + hashFrom(getIntent()));
    }

    private boolean night() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    private void paintBars() {
        Window w = getWindow();
        boolean dark = night();
        int bg = dark ? 0xff0a0e14 : 0xfff2f4f7;
        w.setStatusBarColor(bg);
        w.setNavigationBarColor(dark ? 0xff131920 : Color.WHITE);
        View d = w.getDecorView();
        d.setSystemUiVisibility(dark ? 0 : (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR));
    }

    private boolean isApp(Uri u) {
        Uri app = Uri.parse(BuildConfig.APP_URL);
        String path = u.getPath() == null ? "/" : u.getPath();
        String base = app.getPath() == null ? "/" : app.getPath();
        return u.getHost() != null && u.getHost().equalsIgnoreCase(app.getHost()) && path.startsWith(base.replaceAll("/+$", ""));
    }

    private void showOffline() {
        String html = "<html><body style='font-family:sans-serif;padding:32px;background:" + (night() ? "#0a0e14;color:#e7ecf2" : "#f2f4f7;color:#0e1621") + "'>"
                + "<h2>Scoreline can't connect</h2><p>Check your internet connection, then try again.</p>"
                + "<p><button style='font-size:16px;padding:10px 18px' onclick=\"location.href='" + BuildConfig.APP_URL + "'\">Try again</button></p></body></html>";
        web.loadDataWithBaseURL(BuildConfig.APP_URL, html, "text/html", "utf-8", null);
    }

    private static String hashFrom(Intent i) {
        String h = i == null ? null : i.getStringExtra("hash");
        return h != null && h.startsWith("#") ? h : "";
    }

    private void js(String code) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String h = hashFrom(intent);
        if (!h.isEmpty()) js("window.scorelineOpen ? window.scorelineOpen(" + JSONObject.quote(h) + ") : (location.hash=" + JSONObject.quote(h) + ")");
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        js("window.onNativeResume && window.onNativeResume()");
        io.execute(() -> {
            Alerts.run(getApplicationContext(), false);
            if (Alerts.needsLive(getApplicationContext())) runOnUiThread(() -> Alerts.startLive(getApplicationContext()));
        });
    }

    @Override
    protected void onPause() {
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        js("window.onNativePermission && window.onNativePermission()");
    }

    @Override
    protected void onDestroy() {
        io.shutdownNow();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    /** Called from the app's JavaScript as window.ScorelineNative. */
    public class Bridge {
        @JavascriptInterface
        public String version() { return BuildConfig.VERSION_NAME; }

        @JavascriptInterface
        public void setConfig(String json) {
            Alerts.setConfig(getApplicationContext(), json);
            io.execute(() -> {
                Alerts.run(getApplicationContext(), false);
                if (Alerts.needsLive(getApplicationContext())) runOnUiThread(() -> Alerts.startLive(getApplicationContext()));
            });
        }

        @JavascriptInterface
        public String permission() {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                return Alerts.prefs(MainActivity.this).getBoolean("asked", false) ? "denied" : "default";
            }
            return nm.areNotificationsEnabled() ? "granted" : "denied";
        }

        @JavascriptInterface
        public void requestPermission() {
            runOnUiThread(() -> {
                boolean asked = Alerts.prefs(MainActivity.this).getBoolean("asked", false);
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED && !asked) {
                    Alerts.prefs(MainActivity.this).edit().putBoolean("asked", true).apply();
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
                } else {
                    Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                    try { startActivity(i); } catch (Exception ignored) { }
                }
            });
        }

        @JavascriptInterface
        public boolean batteryExempt() {
            PowerManager pm = getSystemService(PowerManager.class);
            return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
        }

        @JavascriptInterface
        public void requestBattery() {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
                } catch (Exception e) {
                    try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); } catch (Exception ignored) { }
                }
            });
        }

        @JavascriptInterface
        public void test() {
            Alerts.post(getApplicationContext(), Alerts.CH_GAME, "test", "Scoreline alerts are working", "Alerts arrive even when the app is closed.", "#home");
        }

        @JavascriptInterface
        public String status() {
            try {
                JSONObject o = new JSONObject();
                o.put("lastRun", Alerts.prefs(MainActivity.this).getLong("lastRun", 0));
                o.put("lastError", Alerts.prefs(MainActivity.this).getString("lastError", ""));
                o.put("liveNow", Alerts.prefs(MainActivity.this).getInt("liveNow", 0));
                o.put("games", Alerts.loadGames(MainActivity.this).length());
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        /** Fetches ESPN data or Google News for the app, which browsers can't always read directly. */
        @JavascriptInterface
        public void get(final String url, final String cb) {
            io.execute(() -> {
                boolean ok = false;
                String out;
                try {
                    Uri u = Uri.parse(url);
                    String host = u.getHost() == null ? "" : u.getHost();
                    if (!"https".equals(u.getScheme()) || !(host.endsWith(".espn.com") || host.equals("news.google.com"))) throw new Exception("Not allowed");
                    out = Alerts.get(url);
                    ok = true;
                } catch (Exception e) {
                    out = String.valueOf(e.getMessage());
                }
                js("window.__nativeDone && window.__nativeDone(" + JSONObject.quote(cb) + "," + ok + "," + JSONObject.quote(out) + ")");
            });
        }
    }
}
