package app.scoreline;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.graphics.Typeface;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Shows the Scoreline app and connects it to Android's notifications. */
public class MainActivity extends Activity {
    private WebView web;
    private final ExecutorService io = Executors.newFixedThreadPool(4);
    private static final int REQ_NOTIF = 7;

    private boolean safeMode = false;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        safe(this::paintBars);
        File crash = new File(getFilesDir(), App.CRASH_FILE);
        if (crash.exists() && saved == null) {
            showCrash(crash);
            return;
        }
        startApp(saved);
    }

    private static void safe(Runnable r) {
        try { r.run(); } catch (Throwable ignored) { }
    }

    /** Shows what went wrong last time, so it can be sent along and fixed. */
    private void showCrash(File crash) {
        String report;
        try { report = new String(Files.readAllBytes(crash.toPath()), StandardCharsets.UTF_8); } catch (Exception e) { report = String.valueOf(e); }
        final String text = report;
        boolean dark = night();
        int fg = dark ? 0xffe7ecf2 : 0xff0e1621;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad, pad, pad);
        TextView title = new TextView(this);
        title.setText("Scoreline closed unexpectedly");
        title.setTextSize(22);
        title.setTextColor(fg);
        TextView hint = new TextView(this);
        hint.setText("Tap Copy error and paste it to Claude, or take a screenshot. Then tap Open Scoreline.");
        hint.setTextSize(15);
        hint.setTextColor(fg);
        hint.setPadding(0, pad / 2, 0, pad / 2);
        Button copy = new Button(this);
        copy.setText("Copy error");
        copy.setOnClickListener(v -> {
            ClipboardManager cm = getSystemService(ClipboardManager.class);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Scoreline error", text));
            copy.setText("Copied");
        });
        Button open = new Button(this);
        open.setText("Open Scoreline");
        open.setOnClickListener(v -> {
            crash.delete();
            safeMode = true;
            startApp(null);
        });
        TextView body = new TextView(this);
        body.setText(text);
        body.setTextSize(12);
        body.setTextColor(fg);
        body.setTextIsSelectable(true);
        body.setTypeface(Typeface.MONOSPACE);
        body.setPadding(0, pad / 2, 0, 0);
        box.addView(title);
        box.addView(hint);
        box.addView(copy);
        box.addView(open);
        box.addView(body);
        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        setContentView(sv);
    }

    private void startApp(Bundle saved) {
        safe(() -> Alerts.channels(this));
        if (!safeMode) safe(() -> Alerts.schedule(this));

        web = new WebView(this);
        web.setBackgroundColor(night() ? 0xff0a0e14 : 0xfff2f4f7);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setUserAgentString(s.getUserAgentString() + " ScorelineApp/" + BuildConfig.VERSION_NAME);
        web.addJavascriptInterface(new Bridge(), "ScorelineNative");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (isApp(u)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame()) showOffline();
            }
        });

        if (saved != null) web.restoreState(saved);
        else web.loadUrl(BuildConfig.APP_URL + hashFrom(getIntent()));
    }

    private boolean night() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    private void paintBars() {
        Window w = getWindow();
        boolean dark = night();
        int bg = dark ? 0xff0a0e14 : 0xfff2f4f7;
        w.setStatusBarColor(bg);
        w.setNavigationBarColor(dark ? 0xff131920 : Color.WHITE);
        View d = w.getDecorView();
        d.setSystemUiVisibility(dark ? 0 : (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR));
    }

    private boolean isApp(Uri u) {
        Uri app = Uri.parse(BuildConfig.APP_URL);
        String path = u.getPath() == null ? "/" : u.getPath();
        String base = app.getPath() == null ? "/" : app.getPath();
        return u.getHost() != null && u.getHost().equalsIgnoreCase(app.getHost()) && path.startsWith(base.replaceAll("/+$", ""));
    }

    private void showOffline() {
        String html = "<html><body style='font-family:sans-serif;padding:32px;background:" + (night() ? "#0a0e14;color:#e7ecf2" : "#f2f4f7;color:#0e1621") + "'>"
                + "<h2>Scoreline can't connect</h2><p>Check your internet connection, then try again.</p>"
                + "<p><button style='font-size:16px;padding:10px 18px' onclick=\"location.href='" + BuildConfig.APP_URL + "'\">Try again</button></p></body></html>";
        web.loadDataWithBaseURL(BuildConfig.APP_URL, html, "text/html", "utf-8", null);
    }

    private static String hashFrom(Intent i) {
        String h = i == null ? null : i.getStringExtra("hash");
        return h != null && h.startsWith("#") ? h : "";
    }

    private void js(String code) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String h = hashFrom(intent);
        if (!h.isEmpty()) js("window.scorelineOpen ? window.scorelineOpen(" + JSONObject.quote(h) + ") : (location.hash=" + JSONObject.quote(h) + ")");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web == null) return;
        web.onResume();
        js("window.onNativeResume && window.onNativeResume()");
        if (safeMode) return;
        io.execute(() -> {
            try {
                Alerts.run(getApplicationContext(), false);
                if (Alerts.needsLive(getApplicationContext())) runOnUiThread(() -> safe(() -> Alerts.startLive(getApplicationContext())));
            } catch (Throwable ignored) { }
        });
    }

    @Override
    protected void onPause() {
        if (web != null) web.onPause();
        super.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        js("window.onNativePermission && window.onNativePermission()");
    }

    @Override
    protected void onDestroy() {
        io.shutdownNow();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    /** Called from the app's JavaScript as window.ScorelineNative. */
    public class Bridge {
        @JavascriptInterface
        public String version() { return BuildConfig.VERSION_NAME; }

        @JavascriptInterface
        public void setConfig(String json) {
            safe(() -> Alerts.setConfig(getApplicationContext(), json));
            io.execute(() -> {
                try {
                    Alerts.run(getApplicationContext(), false);
                    if (Alerts.needsLive(getApplicationContext())) runOnUiThread(() -> safe(() -> Alerts.startLive(getApplicationContext())));
                } catch (Throwable ignored) { }
            });
        }

        @JavascriptInterface
        public String permission() {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                return Alerts.prefs(MainActivity.this).getBoolean("asked", false) ? "denied" : "default";
            }
            return nm.areNotificationsEnabled() ? "granted" : "denied";
        }

        @JavascriptInterface
        public void requestPermission() {
            runOnUiThread(() -> {
                boolean asked = Alerts.prefs(MainActivity.this).getBoolean("asked", false);
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED && !asked) {
                    Alerts.prefs(MainActivity.this).edit().putBoolean("asked", true).apply();
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
                } else {
                    Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                    try { startActivity(i); } catch (Exception ignored) { }
                }
            });
        }

        @JavascriptInterface
        public boolean batteryExempt() {
            PowerManager pm = getSystemService(PowerManager.class);
            return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
        }

        @JavascriptInterface
        public void requestBattery() {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
                } catch (Exception e) {
                    try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); } catch (Exception ignored) { }
                }
            });
        }

        @JavascriptInterface
        public void test() {
            Alerts.post(getApplicationContext(), Alerts.CH_GAME, "test", "Scoreline alerts are working", "Alerts arrive even when the app is closed.", "#home");
        }

        @JavascriptInterface
        public String status() {
            try {
                JSONObject o = new JSONObject();
                o.put("lastRun", Alerts.prefs(MainActivity.this).getLong("lastRun", 0));
                o.put("lastError", Alerts.prefs(MainActivity.this).getString("lastError", ""));
                o.put("liveNow", Alerts.prefs(MainActivity.this).getInt("liveNow", 0));
                o.put("games", Alerts.loadGames(MainActivity.this).length());
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        /** Fetches ESPN data or Google News for the app, which browsers can't always read directly. */
        @JavascriptInterface
        public void get(final String url, final String cb) {
            io.execute(() -> {
                boolean ok = false;
                String out;
                try {
                    Uri u = Uri.parse(url);
                    String host = u.getHost() == null ? "" : u.getHost();
                    if (!"https".equals(u.getScheme()) || !(host.endsWith(".espn.com") || host.equals("news.google.com"))) throw new Exception("Not allowed");
                    out = Alerts.get(url);
                    ok = true;
                } catch (Exception e) {
                    out = String.valueOf(e.getMessage());
                }
                js("window.__nativeDone && window.__nativeDone(" + JSONObject.quote(cb) + "," + ok + "," + JSONObject.quote(out) + ")");
            });
        }
    }
}
